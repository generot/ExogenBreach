﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveableObj : MonoBehaviour
{
    public float mass;
    private void Start() { mass = 50f; }
}
